package part2;

import java.util.Random;
/**
 * Using Markov process for creating text based on textual databases
 */
public interface IMarkovModel {

    /**
     *Initialization of myText with a given text
     *
     * @param text is a given text
     */
    public void setTraining(String text);

    /**
     * Get a random text which is based on the N letters before
     *
     * step 1: finding all the following chars of that substring and keep it in Array List
     * step 2: choosing a random letter from 'following' and add it to the result text ('sb')
     *
     *
     * @param numChars  is the length of the text we're interested
     * @return a string which include a text which rely on the past N letters only
     *
     * exceptions: 1.If myText is null it will return empty string
     *             2.If the Array List 'following' is empty it will break and return the string until now
     */
    public String getRandomText(int numChars);

    /**
     * Receives as input (seed) to initialize the myRandom variable
     *
     * @param seed number which allowing to Control
     * the values that will be set to us by the myRandom variable
     */
    public void setSeed(int seed);
    
}
