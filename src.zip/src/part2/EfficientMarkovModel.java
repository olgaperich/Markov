package part2;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.stream.Collectors;

/**
 * Improving the Method getRandomText : Each time we will do not have to find
 * the set of characters that followed after the key -we will save it and use it Immediately with HashMap
 *
 * flag: 1 if we already build a Map, 0 otherwise
 */
    public class EfficientMarkovModel extends AbstractMarkovModel {
    protected HashMap<String, ArrayList<String>> hashMapFollow;
    protected int flag = 0;
    /**
     * Constructor
     *
     * @param number specific length of the characters to select the next character
     */
    public EfficientMarkovModel(int number) {
        super(number);
        hashMapFollow = new HashMap<>();
    }

    @Override
    public String toString() {
        return "EfficientMarkovModel of order " + N;
    }


    /**
     * Build the HashMap variable
     *
     */
    public void buildMap(){
        String key;
        int charNum;
        for (int i=0;i<myText.length()-N;i++){
            key = myText.substring(i, i + N);
            if (hashMapFollow.containsKey(key))
                continue;
            else {
                ArrayList<String> followsList = new ArrayList<>();
                charNum=0;
                while (myText.indexOf((key),charNum) != -1)
                {
                    charNum=myText.indexOf((key),charNum);
                    if(key.length() + charNum < myText.length()) {
                        followsList.add(myText.substring(charNum + N, charNum + N + 1));
                        charNum++;
                    }
                    else
                        break;

                    hashMapFollow.put(key,followsList);
                }
                hashMapFollow.put(key,followsList);
            }
        }
    }


    public ArrayList<String> getFollows(String key) {
        return hashMapFollow.get(key);
    }



    public String getRandomText(int numChars){
        if (myText == null){
            return "";
        }
        if(flag==0) {
            buildMap();
            flag = 1;
        }
        StringBuilder sb = new StringBuilder();
        //choosing first n and insert to sb
        int index = myRandom.nextInt(myText.length()-N);
        String key = myText.substring(index,index+N);
        ArrayList<String > following = getFollows(key);
        sb.append(key);
        int newIndex =1;
        for (int i=0;i<numChars-N;i++) {
            if (following.size() == 0) {
                break;
            }
            index = myRandom.nextInt(following.size());
            sb.append(following.get(index));
            key = sb.toString().substring(newIndex,newIndex+N);
            following = getFollows(key);
            newIndex++;
        }
        return sb.toString();
    }


//    public String getRandomText(int numChars) {
//        if (myText == null) {
//            return "";
//        }
//        int index = myRandom.nextInt(myText.length() - N);
//        StringBuilder sb = new StringBuilder();
//        String key = myText.substring(index, index + N);
//        sb.append(key);
//        for (int i = 0; i < numChars - N; i++) {
//            ArrayList<String> followList = getFollows(key);
//            if (followList.size() != 0 ) {
//                index = myRandom.nextInt(followList.size());
//            }
//            sb.append(followList.get(index));
//            key = key.substring(1, N) + followList.get(index);
//        }
//        return sb.toString();
//    }
}









