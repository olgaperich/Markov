package part2;
import java.util.*;

public abstract class AbstractMarkovModel implements IMarkovModel {
    protected String myText;
    protected Random myRandom;
    protected int N;

    /**
     * constructor
     *
     *
     */
    public AbstractMarkovModel(int number) {
        N = number;
        myRandom = new Random();
    }


    final public void setTraining(String s) {
        myText = s.trim();
    }


    public void setSeed(int seed){ myRandom = new Random(seed);}


    abstract public String getRandomText(int numChars);


    /**
     * The method get a key and using it finding the following chars from myText
     *
     *
     * @param key a string which we want to find all the following chars after that
     * @return all the following chars which is appear in myText
     *
     * exceptions: if key is null it will return a array list with all the chars which are part of the string
     *
     */
     protected ArrayList getFollows(String key) {

        ArrayList followChars = new ArrayList();
        if (key.length() == 0){
            for (int i=0;i<myText.length();i++)
                followChars.add(myText.charAt(i));
            return followChars;
        }

        for (int i=0; i<(myText.length()-key.length());i++){
            if (myText.charAt(i) == key.charAt(0)) {
                int j = 0;
                while ((j < key.length()) && myText.charAt((i+j)) == key.charAt(j)) {
                    if ((j) == key.length()-1) {
                        followChars.add(myText.charAt((i+j) + 1));
                        break;
                    }
                    j++;
                }
            }
        }
        return followChars;
    }


    @Override
    public String toString(){
        return "MarkovModel of order " + N;
    }
}
