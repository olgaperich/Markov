package part2;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 */
public class MarkovFour extends AbstractMarkovModel {
    /**
     *constructor
     */
    public MarkovFour() {
       super(4);
    }


    public String getRandomText(int numChars) {

        if (myText == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        //choosing first 4 and insert to sb
        int index = myRandom.nextInt(myText.length() - 4);
        String key = myText.substring(index, index + 4);
        ArrayList<Character> following = getFollows(key);
        sb.append(key);
        int newIndex = 1;


        for (int i = 0; i < numChars - 4; i++) {
            if (following.size() == 0) {
                break;
            }
            index = myRandom.nextInt(following.size());
            sb.append(following.get(index));
            key = sb.toString().substring(newIndex, newIndex + 4);
            following.clear();
            following = getFollows(key);
            newIndex++;
        }
        return sb.toString();
    }
}



