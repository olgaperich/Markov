package part2;

import java.util.ArrayList;
import java.util.Random;

/**
 * The class is been used for finding the next following letter based on N letters before
 */
public class MarkovModel extends AbstractMarkovModel {

        /**
         * Constructor
         *
         * @param number specific length of the characters to select the next character
        */
        public MarkovModel(int number) {
            super(number);
        }

        public String getRandomText(int numChars){

            if (myText == null){
                return "";
            }
            StringBuilder sb = new StringBuilder();
            //choosing first n and insert to sb
            int index = myRandom.nextInt(myText.length()-N);
            String key = myText.substring(index,index+N);
            ArrayList<Character> following = getFollows(key);
            sb.append(key);
            int newIndex =1;


            for (int i=0;i<numChars-N;i++) {
                if (following.size() == 0) {
                    break;
                }
                index = myRandom.nextInt(following.size());
                sb.append(following.get(index));
                key = sb.toString().substring(newIndex,newIndex+N);
                following.clear();
                following = getFollows(key);
                newIndex++;
            }
            return sb.toString();
        }

    }




