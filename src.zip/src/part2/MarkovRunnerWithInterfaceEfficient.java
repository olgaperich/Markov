package part2;

import Part1.MarkovRunner;
import util.SEFileUtil;
import java.io.IOException;

/**
 * The class is use to generate random text using HashMap
 *
 */
public class MarkovRunnerWithInterfaceEfficient {

    /**
     * Printing the object Model and the text we created by the 'getRandomText' function
     *
     * @param markov Object of Markov-N
     * @param text To name of text file given us by the main input array
     * @param size length of text
     * @param seed Control the values that will be set to us from myRandom variable
     */
    public void runModel(IMarkovModel markov, String text, int size, int seed) {
        markov.setSeed(seed);
        markov.setTraining(text);
        System.out.println("running with " + markov);
        for (int k = 0; k < 3; k++) {
            String st = markov.getRandomText(size);
            printOut(st);
        }
    }



    /**
     * The method get a text(myRandom) we made and printing it out, the paragraph separate by "--" lines
     * Each line will include 60 chars
     *
     * @param s is the text we want to print
     */
    private void printOut(String s) {
        String[] words = s.split("\\s+");
        int psize = 0;
        System.out.println("----------------------------------");
        for (int k = 0; k < words.length; k++) {
            System.out.print(words[k] + " ");
            psize += words[k].length() + 1;
            if (psize > 60) {
                System.out.println();
                psize = 0;
            }
        }
        System.out.println("\n----------------------------------");
    }

    /** Print selected num of chars(500 here) based on what does Markov-N based HashMap
     * used text which we got from the 'trainingFilePath'
     *
     * @param trainingFilePath include a path to a text
     * @param seed Control the values that will be set to us from myRandom variable
     *
     */
    public void testHashMap(String trainingFilePath, int seed) {
        SEFileUtil seFileUtil = new SEFileUtil(trainingFilePath);
        String st = seFileUtil.asString();
        st = st.replace('\n', ' ');
        int size = 200;
        EfficientMarkovModel emFive = new EfficientMarkovModel(5);
        runModel(emFive, st, size, seed);
    }

    /**
     * Test input
     *
     * @param args Input to the program
     * exceptions: 1.The inserted number of arg different from exactly two arg
     *             2.NumberFormatException if the second arg is not an integer
     */
    public void checkInput(String[] args) {
        if (args.length != 2) {
            System.out.println("Please pass two arguments: 1.input_file 2.seed");
            System.exit(1);
        }
        try {
            int seed = Integer.parseInt(args[1]);
            //testHashMap(args[0], seed);
        } catch (NumberFormatException seed) {
            System.out.println("The second argument must be an integer");
            System.exit(1);
        }
    }

    public static void main(String[] args) {
        MarkovRunnerWithInterfaceEfficient markov = new MarkovRunnerWithInterfaceEfficient();
        markov.checkInput(args);
        markov.testHashMap(args[0],Integer.parseInt(args[1]));

//        markov.testHashMap("./Data/alice.txt",666);
    }
}