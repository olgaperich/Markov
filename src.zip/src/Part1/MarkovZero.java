package Part1;
import java.util.ArrayList;
import java.util.Random;
/**
 * the class is been used for finding the choosing random chars
 */

public class MarkovZero {
    private String myText;
	private Random myRandom;
	/**
	 *constructor
	 */
	public MarkovZero() {
		myRandom = new Random();
	}
	/**
	 *used for controlling the values which myRandom is going to get, based on integer 'seed'
	 * @param seed an integer which is keeping the results of random test
	 */
	public void setSeed(int seed){ myRandom = new Random(seed);
	}
	/**
	 *initialization of myText with a text
	 * @param s is a text
	 */
	public void setTraining(String s){
		myText = s.trim();
	}
	/**
	 *get a random text and return it
	 *
	 * @param numChars  is the length of the text as we wish to get from the method
	 * @return a string of random chars
	 * exceptions: 1.if myText is null it will return empty string
	 */
	public String getRandomText(int numChars){
		if (myText == null){
			return "";
		}
		StringBuilder sb = new StringBuilder();
		for(int k=0; k < numChars; k++){
			int index = myRandom.nextInt(myText.length());
			sb.append(myText.charAt(index));
		}
		
		return sb.toString();
	}

}