package Part1;
import java.util.ArrayList;
import java.util.Random;
/**
 * the class is been used for finding the next following letter based on 1 letters before
 */
public class MarkovOne {
    private String myText;
    private Random myRandom;

    /**
     *constructor
     */
    public MarkovOne() {
        myRandom = new Random();
    }

    /**
     *used for controlling the values which myRandom is going to get, based on integer 'seed'
     * @param seed an integer which is keeping the results of random test
     */
    public void setSeed(int seed) {
        myRandom = new Random(seed);
    }
    /**
     *initialization of myText with a text
     * @param s is a text
     */
    public void setTraining(String s) {
        myText = s.trim();
    }
    /**
     *get a random text which is based on the 1 letters before.
     *
     * each time it look on the 1 letters before, finding all the following chars of that substring and keep
     *it in Array List which is called 'following'
     * then its choosing a random letter from 'following' and ad it to the result text ('sb')
     *
     * Here we use an method "getFollows" which is returns the following chars after a substring
     *
     * @param numChars  is the length of the text as we wish to get from the method
     * @return a string which include a text which rely on the past 1 letters only
     * exceptions: 1.if myText is null it will return empty string
     *             2.if the Array List 'following' is empty it will break and return the string untill now
     */
    public String getRandomText(int numChars){

    if (myText == null){
        return "";
    }
    StringBuilder sb = new StringBuilder();
        //choosing first 1 and insert to sb
    int index = myRandom.nextInt(myText.length()-1);
    String key = myText.substring(index,index+1);
    ArrayList<Character> following = getFollows(key);
    sb.append(key);
    int newIndex =1;

        //check
        for (int i=0;i<numChars-1;i++) {
            if (following.size() == 0) {
                break;
        }
            index = myRandom.nextInt(following.size());
            sb.append(following.get(index));
            key = sb.toString().substring(newIndex,newIndex+1);
            following.clear();
            following = getFollows(key);
            newIndex++;
    }
    return sb.toString();
}
    /**
     *The method get a key and is been used for finding the following chars after that key in myText
     *
     * every time we called it its check in all myText and looking for key, if exsist it save the follow char,
     * in the end it return all the following chars
     *
     * @param key - a string which we want to find all the following chars after that
     * @return all the following chars which is appear in myText
     * exceptions: if key is null it will return a array list with all the chars which part of the string
     *
     */
    public ArrayList getFollows(String key) {

        ArrayList followChars = new ArrayList();
        if (key.length() == 0){
            for (int i=0;i<myText.length();i++)
                followChars.add(myText.charAt(i));
            return followChars;
        }

        for (int i=0; i<(myText.length()-key.length());i++){
            if (myText.charAt(i) == key.charAt(0)) {
                int j = 0;
                while ((j < key.length()) && myText.charAt((i+j)) == key.charAt(j)) {
                    if ((j) == key.length()-1) {
                        followChars.add(myText.charAt((i+j) + 1));
                        break;
                    }
                    j++;
                }
            }
        }
        return followChars;
    }
}

