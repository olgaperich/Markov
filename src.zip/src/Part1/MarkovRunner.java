package Part1;
import util.*;
/**
 * Execute tests of MarkovRunner
 *
 * Various variants are used to test the code using N=0,1,3,M
 * where N is the number of letters.
 */
public class MarkovRunner {

	/**
	 *The method is taking a training file path and convert it to a text, also it separate each enter to space
	 *
	 * @param trainingFilePath  include a path to a text
	 * @return string which include text
	 */
	private String convertToString(String trainingFilePath){
		SEFileUtil seFileUtil = new SEFileUtil(trainingFilePath);
		String st = seFileUtil.asString();
		st = st.replace('\n', ' ');
		return st;
	}

	/** Print selected num of chars (con. 500) based on what does MarkovZero
	 * used for running the class MarkovZero on the text which we got from the 'trainingFilePath'
	 *
	 * @param trainingFilePath include a path to a text
	 */
    public void runMarkovZero(String trainingFilePath) {
		String st = convertToString(trainingFilePath);
		MarkovZero markov = new MarkovZero();
		markov.setSeed(25);
		markov.setTraining(st);
		for(int k=0; k <3; k++){
			String text = markov.getRandomText(500);
			printOut(text);
		}
	}

	/**Print selected num of chars(500 here) based on what does MarkovOne
	 *used for running the class MarkovOne on the text which we got from the 'trainingFilePath'
	 * @param trainingFilePath-include a path to a text
	 */

	public void runMarkovOne(String trainingFilePath) {
		String st = convertToString(trainingFilePath);
		MarkovOne markov = new MarkovOne();
		markov.setSeed(25);
		markov.setTraining(st);
		for(int k=0; k <3; k++){
			String text = markov.getRandomText(500);
			printOut(text);
		}
	}

	/**Print selected num of chars(500 here) based on what does MarkovFour
	 *used for running the class MarkovFour on the text which we got from the 'trainingFilePath'
	 * @param trainingFilePath-include a path to a text
	 */

	public void runMarkovFour(String trainingFilePath) {
		String st = convertToString(trainingFilePath);
		MarkovFour markov = new MarkovFour();
		markov.setSeed(25);
		markov.setTraining(st);
		for(int k=0; k <3; k++){
			String text = markov.getRandomText(500);
			printOut(text);
		}
	}

	/**Print selected num of chars(500 here) based on what does MarkovModel
	 *used for running the class MarkovModel on the text which we got from the 'trainingFilePath'
	 * @param trainingFilePath-include a path to a text
	 */

	public void runMarkovModel(String trainingFilePath) {
		String st = convertToString(trainingFilePath);
		MarkovModel markov = new MarkovModel(6);
		markov.setSeed(25);
		markov.setTraining(st);
		for(int k=0; k <3; k++){
			String text = markov.getRandomText(500);
			printOut(text);
		}
	}

	/**
	 *The method get a text(myRandom) we made and printing it out, the paragraph separate by lines like "----------------------------------"
	 * Each line will include 60 chars
	 * @param s is the text we want to print
	 */
	private void printOut(String s){
		String[] words = s.split("\\s+");
		int psize = 0;
		System.out.println("----------------------------------");
		for(int k=0; k < words.length; k++){
			System.out.print(words[k]+ " ");
			psize += words[k].length() + 1;
			if (psize > 60) {
				System.out.println();
				psize = 0;
			}
		}
		System.out.println("\n----------------------------------");
	}

	public static void main(String[] args) {
		MarkovRunner markovRunner = new MarkovRunner();
		markovRunner.runMarkovZero(args[0]);
		markovRunner.runMarkovOne(args[0]);
		markovRunner.runMarkovFour(args[0]);
		markovRunner.runMarkovModel(args[0]);


//		markovRunner.runMarkovZero("./Data/merkel.txt");
//		markovRunner.runMarkovOne("./Data/merkel.txt");
//		markovRunner.runMarkovFour("./Data/merkel.txt");
//		markovRunner.runMarkovModel("./Data/merkel.txt");
	}
}
	

