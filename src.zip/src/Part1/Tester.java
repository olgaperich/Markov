package Part1;
import java.util.ArrayList;

/**
 * tester class is been used to test the method "testGetFollows"
 */
public class Tester {

    private static void testGetFollows() {
        MarkovFour markov = new MarkovFour();
        markov.setTraining("this is a test yes this is a test.\n");
        ArrayList a = markov.getFollows("es");
        System.out.println(a);

    }
    public static void main(String[] args) {
        testGetFollows();

    }
}