package Part1;
import java.util.ArrayList;
import java.util.Random;
/**
 * The class is been used for finding the next following letter based on N letters before.
 */
public class MarkovModel {

        private String myText;
        private Random myRandom;
        private int N;

    /**
     *constructor
     *
     * @param number of letters before.
     */
        public MarkovModel(int number) {
            myRandom = new Random();
            N = number;
        }

    /**
     *Used for controlling the values which myRandom is going to get, based on integer 'seed'
     *
     * @param seed keeping the results of random test
     */
        public void setSeed(int seed){ myRandom = new Random(seed);
        }

    /**
     *Initialization of myText with a given text
     *
     * @param s is a given text
     */
        public void setTraining(String s){
            myText = s.trim();
        }

    /**
     * Get a random text which is based on the N letters before
     *
     * step 1: finding all the following chars of that substring and keep it in Array List
     * step 2: choosing a random letter from 'following' and add it to the result text ('sb')
     *
     *
     * @param numChars  is the length of the text we're interested
     * @return a string which include a text which rely on the past N letters only
     *
     * exceptions: 1.If myText is null it will return empty string
     *             2.If the Array List 'following' is empty it will break and return the string until now
     */
        public String getRandomText(int numChars){

            if (myText == null){
                return "";
            }
            StringBuilder sb = new StringBuilder();
            //choosing first n and insert to sb
            int index = myRandom.nextInt(myText.length()-N);
            String key = myText.substring(index,index+N);
            ArrayList<Character> following = getFollows(key);
            sb.append(key);
            int newIndex =1;

            for (int i=0;i<numChars-N;i++) {
                if (following.size() == 0) {
                    break;
                }
                index = myRandom.nextInt(following.size());
                sb.append(following.get(index));
                key = sb.toString().substring(newIndex,newIndex+N);
                following.clear();
                following = getFollows(key);
                newIndex++;
            }
            return sb.toString();
        }


    /**
     * The method get a key and using it finding the following chars from myText
     *
     *
     * @param key a string which we want to find all the following chars after that
     * @return all the following chars which is appear in myText
     *
     * exceptions: if key is null it will return a array list with all the chars which are part of the string
     *
     */
        public ArrayList getFollows(String key) {

            ArrayList followChars = new ArrayList();
            if (key.length() == 0){
                for (int i=0;i<myText.length();i++)
                    followChars.add(myText.charAt(i));
                return followChars;
            }

            for (int i=0; i<(myText.length()-key.length());i++){
                if (myText.charAt(i) == key.charAt(0)) {
                    int j = 0;
                    while ((j < key.length()) && myText.charAt((i+j)) == key.charAt(j)) {
                        if ((j) == key.length()-1) {
                            followChars.add(myText.charAt((i+j) + 1));
                            break;
                        }
                        j++;
                    }
                }
            }
            return followChars;
        }
    }




